package com.fst.immobilier.service;

import com.fst.immobilier.entity.Visite;
import com.fst.immobilier.repository.VisiteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VisiteService {

    @Autowired
    private VisiteRepository visiteRepository;

    public List<Visite> findAll() {
        return visiteRepository.findAll();
    }

    public Visite save(Visite visite) {
        return visiteRepository.save(visite);
    }
}
