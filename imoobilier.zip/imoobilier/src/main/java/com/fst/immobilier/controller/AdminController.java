package com.fst.immobilier.controller;

import com.fst.immobilier.service.StatistiquesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private StatistiquesService statistiquesService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("stats", statistiquesService.getDashboardStats());
        return "admin/dashboard";
    }
}
